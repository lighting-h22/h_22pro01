package server;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import model.Player;
import model.Retinue;
import model.situation;

/*
 * ��Ϣ�����࣬��д���췽����
 * �õ���Ϣ���ͷ��Լ����е������ӿͻ���
 */
public class NotifyHandler extends Thread {
	Socket socket = null;
	InputStream in = null;
	Map<Integer, Socket> sessionMap = null;

	public NotifyHandler(Socket socket, Map<Integer, Socket> sessionMap) {
		this.socket = socket;
		this.sessionMap = sessionMap;
	}

	public void run() {
		int i = 1;
		try {
			in = socket.getInputStream();

			try {
				Player.getCardGroup(i++);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// ʵ��һ�����Ӷ��ͨ��
			while (true) {
				ObjectInputStream ois = new ObjectInputStream(in);
				try {
					Message msg = (Message) ois.readObject();

					// ��������
					try {
						Socket targetSocket = sessionMap.get(msg.getId());
						OutputStream out = targetSocket.getOutputStream();
						ObjectOutputStream oos = new ObjectOutputStream(out);
						int order[] = msg.getOrder();
						if (order[1] == 1001) {
							try {
								Player.drawCardGroup(order[0]);

							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						if (order[1] == 1002) {
							System.out.println(order[0]);
							System.out.println(order[1]);
							System.out.println(order[2]);
							System.out.println(order[3]);
							try {
								Player.summon(order[0], order[2], order[3]);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
						if (order[1] == 1003) {
							System.out.println(order[0]);
							System.out.println(order[1]);
							System.out.println(order[2]);
							System.out.println(order[3]);
							try {
								Retinue.attack(order[0], order[2], order[3]);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
						try {
							msg.setR(situation.getTabel());
							msg.setP(situation.getTabel2());
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("��Ϣ���ܶ��󣺿ͻ���" + msg.getId()
								+ "��\t��Ϣ���ݣ�" + msg.getMsg());
						oos.writeObject(msg);
						oos.flush();

						if (msg.getId() == 1) {
							Socket targetSocket2 = sessionMap.get(2);
							OutputStream out2 = targetSocket2.getOutputStream();
							ObjectOutputStream oos2 = new ObjectOutputStream(
									out2);
							oos2.writeObject(msg);
							oos2.flush();

						}
						if (msg.getId() == 2) {
							Socket targetSocket1 = sessionMap.get(1);
							OutputStream out1 = targetSocket1.getOutputStream();
							ObjectOutputStream oos1 = new ObjectOutputStream(
									out1);
							oos1.writeObject(msg);
							oos1.flush();

						}
						// Socket targetSocket1 = sessionMap.get(1);
						// Socket targetSocket2 = sessionMap.get(2);

						// OutputStream out1 = targetSocket1.getOutputStream();
						// OutputStream out2 = targetSocket2.getOutputStream();

						// ObjectOutputStream oos1 = new
						// ObjectOutputStream(out1);
						// ObjectOutputStream oos2 = new
						// ObjectOutputStream(out2);
						// ��ȡ���ݿ⣬newһ��situation

						/*
						 * if (msg.getId() == 1) { oos2.writeObject(msg);
						 * oos2.flush(); } else if (msg.getId() == 2) {
						 * oos1.writeObject(msg); oos1.flush(); }
						 */
						// ˫��������situation
						System.out.println("�������ת��");
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (socket.isClosed()) {
						break;
					}
				} catch (IOException e) {
					e.printStackTrace();
					try {
						socket.close();
						break;
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
