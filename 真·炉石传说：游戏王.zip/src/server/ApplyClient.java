package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;
import java.util.ArrayList;

import model.Retinue;

public class ApplyClient {
	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;

	private static void init() throws UnknownHostException, IOException {
		s = new Socket("127.0.0.1", 10171);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}

	public int login(String uid, String upassword) throws UnknownHostException,
			IOException {
		init();
		oos.writeInt(1);
		oos.flush();
		oos.writeUTF(uid);
		oos.flush();
		oos.writeUTF(upassword);
		oos.flush();
		int result = ois.readInt();
		return result;
	}

	public void initT() throws UnknownHostException,
			IOException {
		init();
		oos.writeInt(2);
		oos.flush();


	}

	public String getC(String uid, String upassword)
			throws UnknownHostException, IOException {
		init();
		oos.writeInt(2);
		oos.flush();
		oos.writeUTF(uid);
		oos.flush();
		oos.writeUTF(upassword);
		oos.flush();
		String result = ois.readUTF();
		return result;
	}

	public ArrayList<Retinue> searchUser() throws UnknownHostException,
			ClassNotFoundException, IOException {
		// if (s == null)
		init();
		oos.writeInt(3);
		oos.flush();
		ArrayList<Retinue> users = (ArrayList<Retinue>) ois.readObject();
		return users;

	}

}
