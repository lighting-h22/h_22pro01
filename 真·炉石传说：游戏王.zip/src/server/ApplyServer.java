package server;

import java.io.*;
import java.net.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import util.DataConnection;
import model.*;

;

public class ApplyServer {
	private Socket s;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;

	public ApplyServer() throws UnknownHostException, IOException,
			SQLException, ClassNotFoundException {
		ServerSocket ss = new ServerSocket(10171);
		while (true) {
			s = ss.accept();
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			int command = ois.readInt();

			if (command == 1) {
				this.s_login();
			}
			if (command == 2){
				this.initTable();
			}

		}
	}

	String sql;

	public void s_login() throws UnknownHostException, IOException,
			SQLException, ClassNotFoundException {
		String uid = ois.readUTF();
		String upassword = ois.readUTF();
		sql = "select * from player where id='" + uid + "' and password = '"
				+ upassword + "';";
		ResultSet rs = DataConnection.getstate().executeQuery(sql);
		System.out.println(2);
		System.out.println(rs.next());

		oos.writeInt(rs.getInt(1));

		oos.flush();

	}
	public void initTable() throws SQLException, ClassNotFoundException {
		// �½�һ�������ݵı�retinue2����������ݸ�retinue�ĳ�ʼֵһ�£������������
		String sql = "select * from retinue2";
		Retinue retinue = null;
		ResultSet rs = DataConnection.getstate().executeQuery(sql);
		while (rs.next()) {
			retinue = new Retinue(rs.getInt("id"), rs.getString("name"), rs
					.getInt("health1"), rs.getInt("health2"), rs
					.getInt("attack1"), rs.getInt("attack2"), rs
					.getInt("state1"), rs.getInt("state2"), rs
					.getInt("location1"), rs.getInt("location2"), rs.getInt("cost"));
			// System.out.println(retinue.getHp1());
			// System.out.println(retinue.getHp2());
			System.out.println(retinue.getLocation1());
			System.out.println(retinue.getLocation2());
			System.out.println(retinue.getState1());
			System.out.println(retinue.getState2());
			// ����retinue����
			String sql2 = "update retinue set health1 = " + retinue.getHp1()
					+ ", health2 = " + retinue.getHp1() + ", location1 = "
					+ retinue.getLocation1() + ", location2 = "
					+ retinue.getLocation2() + ", state1 = "
					+ retinue.getState1() + ", state2 = " + retinue.getState2()
					+ " where id = " + retinue.getId() + ";";
			int result = DataConnection.getstate().executeUpdate(sql2);
			if (result == 1) {
				System.out.println("���ݴ��ڣ��Ѹ���");
			}
			// ��retinue2����retinue���������������
			else if (result == 0) {
				System.out.println("��2����ԭ��");
				String sql3 = "insert into retinue valuse(" + retinue.getId()
						+ ",'" + retinue.getName() + "'," + retinue.getHp1()
						+ "," + retinue.getHp2() + "," + retinue.getAtk1()
						+ "," + retinue.getAtk2() + ","
						+ retinue.getLocation1() + "," + retinue.getLocation2()
						+ "," + retinue.getState1() + "," + retinue.getState2()
						+ "," + retinue.getCost() + "," + ") ";
				DataConnection.getstate().executeUpdate(sql3);
				System.out.println("���³ɹ���");
			} else {
				System.out.println("δ֪����");
			}

		}

	}




	public static void main(String[] args) {
		try {
			new ApplyServer();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}