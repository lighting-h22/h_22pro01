package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import test.lb;
import util.GVar;
import util.IntVar;
import util.imgg;
import view.GameInterface;

import model.Player;
import model.Retinue;

/*
 * �ͻ���
 */
public class MsgSocketClient {
	static Socket socket = null;
	static InputStreamReader input = null;
	static InputStream in = null;
	static OutputStream out = null;
	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;
	int id;

	public static void socketStart() throws UnknownHostException,
			IOException {


		socket = new Socket("127.0.0.1", 8989);
		System.out.println("�ͻ���1������������");
		// ���ܷ��ص�����
		MsgSocketClient sss = new MsgSocketClient();
		MyThread tt = sss.new MyThread();

		tt.start();

	}

	class MyThread extends Thread {

		public void run() {

			try {
				while (true) {
					in = socket.getInputStream();
					ObjectInputStream ois = new ObjectInputStream(in);
					Message msg = (Message) ois.readObject();
					ArrayList<Retinue> tabel = msg.getR();
					ArrayList<Player> tabel2 = msg.getP();

					// System.out.println("�������ݣ�" + msg.getInstruct()
					// + msg.getMsg());
					MsgSocketClient.updata(tabel, tabel2);
					// if (msg.getInstruct() == 1003)
					// msgs.cont(msg.getContent());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void updata(ArrayList<Retinue> r, ArrayList<Player> p) {
		GameInterface s = IntVar.getGame1();
		ImageIcon x = new ImageIcon("img/"+p.get(0).getHimg());
		s.hero1.setIcon(x);
		s.playerHp1.setText("Hp:"+p.get(0).getHp());
		ImageIcon x2 = new ImageIcon("img/"+p.get(1).getHimg());
		s.hero2.setIcon(x2);
		s.playerHp.setText("Hp:"+p.get(1).getHp());

		s.retinue8.setIcon(null);
		s.hp8.setText("Hp:");
		s.atk8.setText("ATK:");
		s.retinue9.setIcon(null);
		s.hp9.setText("Hp:");
		s.atk9.setText("ATK:");
		s.retinue10.setIcon(null);
		s.hp10.setText("Hp:");
		s.atk10.setText("ATK:");
		s.retinue11.setIcon(null);
		s.hp11.setText("Hp:");
		s.atk11.setText("ATK:");
		s.retinue12.setIcon(null);
		s.hp12.setText("Hp:");
		s.atk12.setText("ATK:");
		s.retinue13.setIcon(null);
		s.hp13.setText("Hp:");
		s.atk13.setText("ATK:");
		s.retinue14.setIcon(null);
		s.hp14.setText("Hp:");
		s.atk14.setText("ATK:");
		s.retinue15.setIcon(null);
		s.hp15.setText("Hp:");
		s.atk15.setText("ATK:");
		s.retinue16.setIcon(null);
		s.hp16.setText("Hp:");
		s.atk16.setText("ATK:");		
		s.retinue17.setIcon(null);
		s.hp17.setText("Hp:");
		s.atk17.setText("ATK:");
		s.retinue18.setIcon(null);
		s.hp18.setText("Hp:");
		s.atk18.setText("ATK:");
		s.retinue19.setIcon(null);
		s.hp19.setText("Hp:");
		s.atk19.setText("ATK:");
		s.retinue20.setIcon(null);
		s.hp20.setText("Hp:");
		s.atk20.setText("ATK:");
		s.retinue21.setIcon(null);
		s.hp21.setText("Hp:");
		s.atk21.setText("ATK:");

		
		for(int j=0;j<r.size();j++){
			if(r.get(j).getState1()==1){
				if(r.get(j).getLocation1()==1){
					s.hand1.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==2){
					s.hand2.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==3){
					s.hand3.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==4){
					s.hand4.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==5){
					s.hand5.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==6){
					s.hand6.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==7){
					s.hand7.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==8){
					s.hand8.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==8){
					s.hand8.setIcon(imgg.getImg(r.get(j).getId()));
				}
				if(r.get(j).getLocation1()==11){
					s.retinue8.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp8.setText("Hp:"+r.get(j).getHp1());
					s.atk8.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==12){
					s.retinue9.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp9.setText("Hp:"+r.get(j).getHp1());
					s.atk9.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==13){
					s.retinue10.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp10.setText("Hp:"+r.get(j).getHp1());
					s.atk10.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==14){
					s.retinue11.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp11.setText("Hp:"+r.get(j).getHp1());
					s.atk11.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==15){
					s.retinue12.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp12.setText("Hp:"+r.get(j).getHp1());
					s.atk12.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==16){
					s.retinue13.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp13.setText("Hp:"+r.get(j).getHp1());
					s.atk13.setText("ATK:"+r.get(j).getAtk1());
				}
				if(r.get(j).getLocation1()==17){
					s.retinue14.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp14.setText("Hp:"+r.get(j).getHp1());
					s.atk14.setText("ATK:"+r.get(j).getAtk1());
				}
			}
			if(r.get(j).getState2()==1){
				if(r.get(j).getLocation2()==11){
					s.retinue21.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp21.setText("Hp:"+r.get(j).getHp2());
					s.atk21.setText("ATK:"+r.get(j).getAtk2());
					
				}
				if(r.get(j).getLocation2()==12){
					s.retinue20.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp20.setText("Hp:"+r.get(j).getHp2());
					s.atk20.setText("ATK:"+r.get(j).getAtk2());
				}
				if(r.get(j).getLocation2()==13){
					s.retinue19.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp19.setText("Hp:"+r.get(j).getHp2());
					s.atk19.setText("ATK:"+r.get(j).getAtk2());
				}
				if(r.get(j).getLocation2()==14){
					s.retinue18.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp18.setText("Hp:"+r.get(j).getHp2());
					s.atk18.setText("ATK:"+r.get(j).getAtk2());
				}
				if(r.get(j).getLocation2()==15){
					s.retinue17.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp17.setText("Hp:"+r.get(j).getHp2());
					s.atk17.setText("ATK:"+r.get(j).getAtk2());
				}
				if(r.get(j).getLocation2()==16){
					s.retinue16.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp16.setText("Hp:"+r.get(j).getHp2());
					s.atk16.setText("ATK:"+r.get(j).getAtk2());
				}
				if(r.get(j).getLocation2()==17){
					s.retinue15.setIcon(imgg.getImg(r.get(j).getId()));
					s.hp15.setText("Hp:"+r.get(j).getHp2());
					s.atk15.setText("ATK:"+r.get(j).getAtk2());
				}
			}

			
		}
		

	}


	public static void myOrder(int order[]) throws ClassNotFoundException,
			IOException {
		out = socket.getOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(out);
		Message message = new Message();
		message.setId(order[0]);
		message.setOrder(order);

		oos.writeObject(message);
		oos.flush();
		System.out.println("�ѷ���");


	}

	public static void main(String[] args) {
		try {
			new MsgSocketClient().socketStart();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

/*
 * ��(�ͻ���1)������ʱ��id���Ե�ֵΪ2����(�ͻ���2)����ʱ��id����Ϊ1�� �˴�����Ϣ���մ������ǰ�棬����Ϊwhile (true){input =
 * new InputStreamReader(System.in); �����������ŵȴ����룬���������Ϣ�Ĵ��������δ����·����ᵼ����û�з�����Ϣ��ʱ��
 * ������Ϣ���̲߳����������ղ�����Ŀͻ��˷�������Ϣ
 */

