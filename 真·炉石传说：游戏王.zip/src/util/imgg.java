package util;

import javax.swing.ImageIcon;



public class imgg {
	static ImageIcon x0 = new ImageIcon();
	static ImageIcon x1 = new ImageIcon("img/retinue/101.png");
	static ImageIcon x2 = new ImageIcon("img/retinue/102.png");
	static ImageIcon x3 = new ImageIcon("img/retinue/103.png");
	static ImageIcon x4 = new ImageIcon("img/retinue/104.png");
	static ImageIcon x5 = new ImageIcon("img/retinue/105.png");
	static ImageIcon x6 = new ImageIcon("img/retinue/106.png");
	static ImageIcon x7 = new ImageIcon("img/retinue/107.png");
	static ImageIcon x8 = new ImageIcon("img/retinue/108.png");
	static ImageIcon x9 = new ImageIcon("img/retinue/109.png");
	static ImageIcon x10 = new ImageIcon("img/retinue/110.png");
	static ImageIcon x11 = new ImageIcon("img/retinue/111.png");
	static ImageIcon x12 = new ImageIcon("img/retinue/112.png");
	static ImageIcon x13 = new ImageIcon("img/retinue/113.png");
	static ImageIcon x14 = new ImageIcon("img/retinue/114.png");
	static ImageIcon x15 = new ImageIcon("img/retinue/115.png");
	static ImageIcon x16 = new ImageIcon("img/retinue/116.png");
	static ImageIcon x17 = new ImageIcon("img/retinue/117.png");
	static ImageIcon x18 = new ImageIcon("img/retinue/118.png");
	static ImageIcon x19 = new ImageIcon("img/retinue/119.png");
	static ImageIcon x20 = new ImageIcon("img/retinue/120.png");
	static ImageIcon x21 = new ImageIcon("img/retinue/120.png");
	static ImageIcon x22 = new ImageIcon("img/retinue/122.png");
	static ImageIcon x23 = new ImageIcon("img/retinue/123.png");
	static ImageIcon x24 = new ImageIcon("img/retinue/124.png");
	static ImageIcon x25 = new ImageIcon("img/retinue/125.png");
	static ImageIcon x26 = new ImageIcon("img/retinue/126.png");
	static ImageIcon x27 = new ImageIcon("img/retinue/127.png");
	static ImageIcon x28 = new ImageIcon("img/retinue/128.png");
	public static ImageIcon getImg(int i) {
		switch (i) {
		case 1:
			return x1;
		case 2:
			return x2;
		case 3:
			return x3;
		case 4:
			return x4;
		case 5:
			return x5;
		case 6:
			return x6;
		case 7:
			return x7;
		case 8:
			return x8;
		case 9:
			return x9;
		case 10:
			return x10;
		case 11:
			return x11;
		case 12:
			return x12;
		case 13:
			return x13;
		case 14:
			return x14;
		case 15:
			return x15;
		case 16:
			return x16;
		case 17:
			return x17;
		case 18:
			return x18;
		case 19:
			return x19;
		case 20:
			return x20;
		case 21:
			return x21;
		case 22:
			return x22;
		case 23:
			return x23;
		case 24:
			return x24;
		case 25:
			return x25;
		case 26:
			return x26;
		case 27:
			return x27;
		case 28:
			return x28;


		default:
			break;
		}
		return x0;
	}

}
