package util;

import java.sql.*;

public class DataConnection {
	public static Statement state;
	public static void init() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://127.0.0.1/lscs";
		String user="root";
		String password="ZXCfor123.";
		Connection connection=DriverManager.getConnection(url,user,password);
		state=connection.createStatement();
	}
	public static Statement getstate() throws ClassNotFoundException, SQLException{
		if(state==null)
			init();
		return state;
	}
}
