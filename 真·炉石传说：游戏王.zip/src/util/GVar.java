package util;

import java.util.ArrayList;

import model.Retinue;

public class GVar {
	private static int cardGroup[]=new int[30];	
	private static int c=0;
	private static int handnull[]={0,0,0,0,0,0,0,0};
	private static ArrayList<Retinue> ggs;
	private static int i1=1;
	private static int i2=2;
	private static int value=-2;
	public static int[] getCardGroup() {
		return cardGroup;
	}
	
	public static void setCardGroup(int[] cardGroup) {
		GVar.cardGroup = cardGroup;
	}
	public static int getC() {
		return c;
	}
	public static void setC(int c) {
		GVar.c = c;
	}
	public static int[] getHandnull() {
		return handnull;
	}
	public static void setHandnull(int[] handnull) {
		GVar.handnull = handnull;
	}
	public static int getCard(){
		value++;
		return cardGroup[c++];		
	}
	public static void setOne(int i){
		GVar.handnull[i]=1;
	}
	public static void setZero(int i){
		GVar.handnull[i]=0;
	}
	public static int getHandnull(int i){
		return handnull[i];
	}
	public static int getNull(){
		for(int i=0;i<8;i++){
			if(GVar.getHandnull(i)==0){
				GVar.setOne(i);
				return (i+1);	
			}
		}
		return -1;
	}

	public static ArrayList<Retinue> getGgs() {
		return ggs;
	}

	public static void setGgs(ArrayList<Retinue> ggs) {
		GVar.ggs = ggs;
	}

	public static int getI1() {
		return i1;
	}

	public static void setI1(int i1) {
		GVar.i1 = i1;
	}

	public static int getI2() {
		return i2;
	}

	public static void setI2(int i2) {
		GVar.i2 = i2;
	}


	
}
