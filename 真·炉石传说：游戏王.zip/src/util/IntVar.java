package util;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import model.Retinue;

import view.*;
public class IntVar {

	private static GameInterface game1;
	private static GameInterface game2;

	public static GameInterface getGame1() {
		return game1;
	}

	public static void setGame1(GameInterface game1) {
		IntVar.game1 = game1;
	}

	public static GameInterface getGame2() {
		return game2;
	}

	public static void setGame2(GameInterface game2) {
		IntVar.game2 = game2;
	}



}
