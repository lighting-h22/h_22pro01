package util;

import java.awt.Point;

public class Location {
	Point p;
	private int or[] = { 11, 12, 13, 14, 15, 16, 17 };

	public Location(Point p) {
		super();
		this.p = p;
	}

	public int getL() {
		if ((367 <= p.x && p.x <= 460) && (452 <= p.y && p.y <= 606)) {
			return or[0];
		} else if ((540 <= p.x && p.x <= 634) && (452 <= p.y && p.y <= 606)) {
			return or[1];
		} else if ((712 <= p.x && p.x <= 804) && (452 <= p.y && p.y <= 606)) {
			return or[2];
		} else if ((883 <= p.x && p.x <= 976) && (452 <= p.y && p.y <= 606)) {
			return or[3];
		} else if ((1054 <= p.x && p.x <= 1150) && (452 <= p.y && p.y <= 606)) {
			return or[4];
		} else if ((1227 <= p.x && p.x <= 1321) && (452 <= p.y && p.y <= 606)) {
			return or[5];
		} else if ((1400 <= p.x && p.x <= 1495) && (452 <= p.y && p.y <= 606)) {
			return or[6];
		} else if ((540 <= p.x && p.x <= 634) && (285 <= p.y && p.y <= 442)) {
			return or[5];
		} else if ((712 <= p.x && p.x <= 804) && (285 <= p.y && p.y <= 442)) {
			return or[4];
		} else if ((883 <= p.x && p.x <= 976) && (285 <= p.y && p.y <= 442)) {
			return or[3];
		} else if ((1054 <= p.x && p.x <= 1150) && (285 <= p.y && p.y <= 442)) {
			return or[2];
		} else if ((1227 <= p.x && p.x <= 1321) && (285 <= p.y && p.y <= 442)) {
			return or[1];
		} else if ((1400 <= p.x && p.x <= 1495) && (285 <= p.y && p.y <= 442)) {
			return or[0];
		} else if ((367 <= p.x && p.x <= 460) && (285 <= p.y && p.y <= 442)) {
			return or[6];
		}
		System.out.println(p);

		return -1;

	}

}
