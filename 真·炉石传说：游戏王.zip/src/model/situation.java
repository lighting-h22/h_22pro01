package model;

import java.io.Serializable;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

public class situation implements Serializable {
	//��ñ���
	public static ArrayList<Retinue> getTabel() throws SQLException,
			ClassNotFoundException {
		ArrayList<Retinue> retinue1 = new ArrayList<Retinue>();
		String sql = "select * from retinue";
		ResultSet rs = util.DataConnection.getstate().executeQuery(sql);
		while (rs.next()) {
			retinue1.add(new Retinue(rs.getInt("id"), rs.getString("name"), rs
					.getInt("health1"), rs.getInt("health2"), rs.getInt("attack1"), rs
					.getInt("attack2"), rs.getInt("state1"), rs.getInt("state2"), rs
					.getInt("location1"), rs.getInt("location2"), rs.getInt("cost")));
		}
		ArrayList<Retinue> retinue2 = new ArrayList<Retinue>();
		for (int i = 0; i < retinue1.size(); i++) {
			if(retinue1.get(i).getState1()==1||retinue1.get(i).getState2()==1){
				retinue2.add(retinue1.get(i));
			}
		}
		return retinue2;
	}

	public static ArrayList<Player> getTabel2() throws SQLException,
			ClassNotFoundException {
		String sql = "select * from player";
		ArrayList<Player> retinue2 = new ArrayList<Player>();
		ResultSet rs = util.DataConnection.getstate().executeQuery(sql);

		while (rs.next()) {
			retinue2.add(new Player(rs.getString(3), rs.getInt(1), rs
					.getString(2), rs.getInt(5), rs.getInt(7),rs.getString(4)));
		}
		return retinue2;

	}

}
