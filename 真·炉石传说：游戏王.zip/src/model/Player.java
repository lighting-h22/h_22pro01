package model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DataConnection;
import util.GVar;
import util.GVar2;

public class Player implements Serializable {

	private String uname;
	private int uid;
	private String upassword;
	private int hp;
	private int c[];
	private int state;
	private String himg;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public void setC(int c[]) {
		this.c = c;
	}

	public int[] getC() {
		return c;
	}

	public Player(int c[]) {
		super();
		this.setC(c);
		// TODO Auto-generated constructor stub
	}

	public Player(String uname, int uid, String upassword, int hp, int state,
			String img) {
		super();
		this.uname = uname;
		this.uid = uid;
		this.upassword = upassword;
		this.hp = hp;
		this.state = state;
		this.himg = img;
	}

	public static void drawCardGroup(int pid) throws SQLException,
			ClassNotFoundException {
		String sql = null;
		if (pid == 2) {
			sql = "Update retinue set state2 =1 , location" + pid + " = "
					+ GVar.getNull() + " where id = " + GVar.getCard() + ";";
		}
		if (pid == 1) {
			sql = "Update retinue set state1 =1 , location" + pid + " = "
					+ GVar2.getNull() + " where id = " + GVar2.getCard() + ";";
		}
		DataConnection.getstate().executeUpdate(sql);

	}


	public static void getCardGroup(int id) throws SQLException,
			ClassNotFoundException {
		// ��һ����������
		String sql = "select * from player where id =' " + id + "';";
		ResultSet rs = util.DataConnection.getstate().executeQuery(sql);
		String c = null;
		if (rs.next()) {
			c = rs.getString("cardgroud");
		}
		String group[] = c.split(" ");
		int cc[] = new int[group.length];
		for (int i = 0; i < cc.length; i++) {
			cc[i] = Integer.parseInt(group[i]);
		}
		if (id == 1) {
			GVar2.setCardGroup(cc);
		} else if (id == 2) {
			GVar.setCardGroup(cc);
		}
	}

	public static String getsss(int id) throws SQLException,
			ClassNotFoundException {
		// ��һ����������
		String sql = "select * from player where id =' " + id + "';";
		ResultSet rs = util.DataConnection.getstate().executeQuery(sql);
		String c = null;
		if (rs.next()) {
			c = rs.getString("himage");
		}
		return c;

	}

	public static void summon(int id, int location1, int location2)
			throws SQLException, ClassNotFoundException {
		// ����ٻ�
		String sql = "update retinue set location" + id + " = " + location2
				+ " where location" + id + "= " + location1 + ";";
		util.DataConnection.getstate().executeUpdate(sql);
		if (id == 1) {
			GVar2.setZero(location1 - 1);
		} else if (id == 2) {
			GVar.setZero(location1 - 1);
		}

	}

	public int pDie() {
		// �ж�����Ƿ�������stateΪtrue��,��֮��
		return state;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getHimg() {
		return himg;
	}

	public void setHimg(String himg) {
		this.himg = himg;
	}

}
