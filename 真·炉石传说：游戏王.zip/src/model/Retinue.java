package model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DataConnection;

public class Retinue implements Serializable {
	private int id;
	private String name;
	private int hp1;
	private int hp2;
	private int atk1;
	private int atk2;
	private int cost;
	private int location1;
	private int location2;
	private int state1;
	private int state2;

	public Retinue(int id, String name, int hp1, int hp2, int atk1, int atk2,
			int state1, int state2, int location1, int location2, int cost) {
		super();
		this.id = id;
		this.name = name;
		this.hp1 = hp1;
		this.hp2 = hp2;
		this.atk1 = atk1;
		this.atk2 = atk2;
		this.cost = cost;
		this.location1 = location1;
		this.location2 = location2;
		this.state1 = state1;
		this.state2 = state2;
	}

	public Retinue(int id) {
		super();
		this.id = id;
		// TODO Auto-generated constructor stub
	}

	public Retinue(int int1, int int2, int int3, int int4, int int5) {
		// TODO Auto-generated constructor stub
		super();
		this.id = int1;
		this.hp1 = int2;
		this.hp2 = int3;

		this.cost = int5;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHp1() {
		return hp1;
	}

	public void setHp1(int hp1) {
		this.hp1 = hp1;
	}

	public int getHp2() {
		return hp2;
	}

	public void setHp2(int hp2) {
		this.hp2 = hp2;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getLocation1() {
		return location1;
	}

	public void setLocation1(int location1) {
		this.location1 = location1;
	}

	public int getLocation2() {
		return location2;
	}

	public void setLocation2(int location2) {
		this.location2 = location2;
	}

	public int isState1() {
		return state1;
	}

	public void setState1(int state1) {
		this.state1 = state1;
	}

	public int isState2() {
		return state2;
	}

	public void setState2(int state2) {
		this.state2 = state2;
	}

	public static void attack(int i, int attacker, int beAttacker)
			throws SQLException, ClassNotFoundException {
		Retinue retinue = null;
		Retinue retinue2 = null;
		int action=0;
		String sql;


		// �жϹ�����λ���Ƿ�Ϊlocation1�����ݿ����ԣ�
		if (i == 1) {
			sql = "select * from retinue where location1=" + attacker + ";";
			ResultSet rs = DataConnection.getstate().executeQuery(sql);

			if (rs.next()) {
				retinue = new Retinue(rs.getInt("id"), rs.getString("name"), rs
						.getInt("health1"), rs.getInt("health2"), rs
						.getInt("attack1"), rs.getInt("attack2"), rs
						.getInt("state1"), rs.getInt("state2"), rs
						.getInt("location1"), rs.getInt("location2"), rs
						.getInt("cost"));
				action = rs.getInt("action"); 
				

			}
		}
		// ���򹥻���λ���Ƿ�Ϊlocation2�����ݿ����ԣ�
		else if (i == 2) {
			sql = "select * from retinue where location2=" + attacker + ";";
			ResultSet rs = DataConnection.getstate().executeQuery(sql);
			if (rs.next()) {
				retinue = new Retinue(rs.getInt("id"), rs.getString("name"), rs
						.getInt("health1"), rs.getInt("health2"), rs
						.getInt("attack1"), rs.getInt("attack2"), rs
						.getInt("state1"), rs.getInt("state2"), rs
						.getInt("location1"), rs.getInt("location2"), rs
						.getInt("cost"));
				action = rs.getInt("action"); 

			}
			// ���޹����ߣ���������
			else {
				System.out.println("�����ڴ�λ�õĹ�����");
				return;
			}
		}
		
		// ������Ϊλ��Ϊlocation1�����ݿ����ԣ�������location2�����ݿ����ԣ�==��������location2�����
		if (i == 1) {
			sql = "select * from retinue where location2=" + beAttacker + ";";
			ResultSet rs = DataConnection.getstate().executeQuery(sql);
			if (rs.next()) {
				retinue2 = new Retinue(rs.getInt("id"), rs.getString("name"),
						rs.getInt("health1"), rs.getInt("health2"), rs
								.getInt("attack1"), rs.getInt("attack2"), rs
								.getInt("state1"), rs.getInt("state2"), rs
								.getInt("location1"), rs.getInt("location2"),
						rs.getInt("cost"));
			}
			// ������Ϊλ��Ϊlocation2�����ݿ����ԣ�������location1�����ݿ����ԣ�==��������location2�����
			else {
				System.out.println("�����ڴ�λ�õı�������");
				return;
			}
		}
		if (i == 2) {
			sql = "select * from retinue where location1=" + beAttacker + ";";
			ResultSet rs = DataConnection.getstate().executeQuery(sql);
			if (rs.next()) {
				retinue2 = new Retinue(rs.getInt("id"), rs.getString("name"),
						rs.getInt("health1"), rs.getInt("health2"), rs
								.getInt("attack1"), rs.getInt("attack2"), rs
								.getInt("state1"), rs.getInt("state2"), rs
								.getInt("location1"), rs.getInt("location2"),
						rs.getInt("cost"));
			} else {
				System.out.println("�����ڴ�λ�õı�������");
				return;
			}
		}

			// ������Ϊlocation1�����ݿ����ԣ�����������
			if (i == 1&&action==1) {
				retinue.setHp1(retinue.hp1 - retinue2.atk2);
				retinue2.setHp2(retinue2.hp2 - retinue.atk1);
				setDie(retinue);
				setDie(retinue2);
				updateRetinue(retinue);
				updateRetinue(retinue2);
				setActionNum(retinue.getId(), 0);
				
				
			}
			// ������Ϊlocation2�����ݿ����ԣ�����������
			else if (i == 2&&action==1) {
				retinue.setHp2(retinue.hp2 - retinue2.atk1);
				retinue2.setHp1(retinue2.hp1 - retinue.atk2);
				setDie(retinue);
				setDie(retinue2);
				updateRetinue(retinue);
				updateRetinue(retinue2);
				setActionNum(retinue.getId(), 0);
			}
		

		System.out.println("���ݸ��³ɹ�");
		return;
	}

	public static  void setActionNum(int id,int action) throws SQLException, ClassNotFoundException{
		String sql="update retinue set action ="+action+" where id = "+ id +";";
		DataConnection.getstate().executeUpdate(sql);
		System.out.println(id+" ����������Ϊ"+action);
	}
	
	// ����һ����ӵ���Ϣ
	public static void updateRetinue(Retinue retinue) throws SQLException,
			ClassNotFoundException {
		String sql = "";
		int i = 0;
		if (retinue != null) {
			sql = "update retinue set health1 = " + retinue.hp1
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);

			sql = "update retinue set health2 = " + retinue.hp2
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);

			sql = "update retinue set location1 = " + retinue.location1
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);
			System.out.println(retinue.location1);
			sql = "update retinue set location2 = " + retinue.location2
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);
			System.out.println(retinue.location2);
			sql = "update retinue set state1 = " + retinue.state1
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);

			sql = "update retinue set state2 = " + retinue.state2
					+ " where id = " + retinue.getId() + ";";
			DataConnection.getstate().executeUpdate(sql);
			System.out.println(i++);
		}
	}

	public static void setDie(Retinue retinue) {
		if (retinue.getHp1() <= 0) {
			retinue.setState1(0);
			retinue.setLocation1(-1);
		}
		if (retinue.getHp2() <= 0) {
			retinue.setState2(0);
			retinue.setLocation2(-1);
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAtk1() {
		return atk1;
	}

	public void setAtk1(int atk1) {
		this.atk1 = atk1;
	}

	public int getAtk2() {
		return atk2;
	}

	public void setAtk2(int atk2) {
		this.atk2 = atk2;
	}

	public int getState1() {
		return state1;
	}

	public int getState2() {
		return state2;
	}
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		setActionNum(1, 1);
	}

}
